class DataTableFilter {
    constructor({
        target,
        storage = null,
        hours = 2
    }) {
        this.wrapper = document.querySelector(`.${target}`);
        this.storage = `DataTables_extra_filter_${storage || window.location.pathname}`;
        this.hours = hours;
    }

    get_fields() {
        let fields = this.wrapper.querySelectorAll("[name]");
        fields = [...fields].filter((field) => !!field.getAttribute("name"));
        this.fields = fields;
        for (const field of fields) {
            const tag = field.tagName.toLowerCase();
            field.addEventListener(tag == "select" ? "change" : "input", ({
                target
            }) => this.save_value(target));
        }
    }

    save_value(target) {
        if (localStorage.getItem(this.storage)) {
            this.update_storage(target);
        } else {
            this.create_storage(target);
        }
    }

    create_storage(field) {
        const name = field.getAttribute("name");
        let data = {};
        data[name] = field.value;
        data["expire_at"] = new Date();
        localStorage.setItem(this.storage, JSON.stringify(data));
    }

    update_storage(field) {
        const name = field.getAttribute("name");
        let data = JSON.parse(localStorage.getItem(this.storage));
        const checkbox = field.getAttribute("type") == "checkbox";
        if (checkbox ? field.checked : field.value) {
            data[name] = field.value;
        } else {
            delete data[name];
        }
        localStorage.setItem(this.storage, JSON.stringify(data));
    }

    set_initial_value() {
        let data = localStorage.getItem(this.storage);
        if (data) {
            data = JSON.parse(data);
            for (const field in data) {
                if (field != "expire_at") {
                    const target = this.wrapper.querySelector(`[name="${field}"]`);
                    if (target.getAttribute("type") == "checkbox") {
                        target.checked = true;
                    } else {
                        target.value = data[field];
                    }
                }
            }
        }
    }

    check_expire_time() {
        let data = localStorage.getItem(this.storage);
        if (data) {
            const expire_time = new Date(JSON.parse(data)["expire_at"]).getTime();
            const hours = this.hours * 60 * 60 * 1000;
            const current_date = new Date().getTime();
            if (current_date - expire_time >= hours) {
                localStorage.removeItem(this.storage);
            }
        }
    }

    init() {
        this.get_fields();
        this.check_expire_time();
        this.set_initial_value();
    }
}

if ($('.js-datatable-extra-filter').length > 0) {
    new DataTableFilter({
        target: 'js-datatable-extra-filter'
    }).init()
}

function Crud(options) {

    var _ = this,
        _btn;
    _.options = options;
    _.currentItem = null;
    _.datatable = null;
    _.progressBar = $('.js-progress-bar');
    _.editData = [];

    _.prepareDatatable = function() {
        var obj = {
            pageLength: _.options.list.datatable.pageLength || 10,
            order: _.options.list.datatable.order || [
                [0, 'desc']
            ],
            processing: true,
            serverSide: true,
            responsive: true,
            stateSave: true,
            stateLoadParams: function(settings, data) {
                if (Date.now() < (data.time + settings.iStateDuration * 1000)) {
                    _.stateLoadParams(data);
                }
            },
            ajax: {
                url: _.options.list.url,
                data: function(d) {
                    return $.extend({}, d, _.options.list.data || {});
                }
            },
            columns: _.options.list.datatable.columns,
            columnDefs: _.options.list.datatable.columnDefs
        };

        var _lang = document.documentElement.lang;
        if (_lang != 'en') {
            obj.language = {
                'url': '/assets/plugins/datatables/lang/' + _lang + '.json'
            };
        }

        if (_.options.list.datatable.rowCallback) {
            obj['rowCallback'] = _.options.list.datatable.rowCallback
        }

        if (_.options.list.datatable.footerCallback) {
            obj['footerCallback'] = _.options.list.datatable.footerCallback
        }

        if (_.options.list.datatable.rowsGroup) {
            obj['rowsGroup'] = _.options.list.datatable.rowsGroup
        }

        if (_.options.list.datatable.drawCallback) {
            obj['drawCallback'] = _.options.list.datatable.drawCallback
        } else {
            obj['drawCallback'] = function(settings) {
                _.tooltip()
                var api = this.api();
                _.addLabels(api)
            }
        }

        return obj;
    }

    _.addLabels = function(api) {
        var $table = $(api.table().node());

        // Create an array of labels containing all table headers
        var labels = [];
        $('thead tr:last-child th', $table).each(function() {
            labels.push($(this).text());
        });

        // Add data-label attribute to each cell
        $('tbody tr', $table).each(function() {
            $(this).find('td').each(function(column) {
                $(this).attr('data-label', labels[column]);
            });
        });

        if ($('thead tr', $table).length > 1) {
            // Add data-label attribute to each cell
            $('thead tr:first-child', $table).each(function() {
                $(this).find('th').each(function(column) {
                    $(this).attr('data-label', labels[column]);
                });
            });
        }
    }

    /**
     * Init datatable Filter by their column index
     */
    _.initDatableFilter = function() {
        $("#datatable thead input, #datatable thead select").on('keyup change', function() {
            _.datatable
                .column($(this).parent().index() + ':visible')
                .search(this.value)
                .draw();
        });
    }

    /**
     * Make a button
     * 
     * @param  obj data
     * @param  string classes
     * @param  string inner  
     * @param  Array dataArr  
     * @param  Array attrs  
     *  
     * @return string
     */
    _.makeButton = function(data, classes, inner, dataArr, attrs) {
        var dataArr = typeof dataArr !== 'undefined' ? dataArr : [],
            dataHtml = 'data-id="' + data.id + '"';

        $.each(dataArr, function(i, val) {
            if (Array.isArray(val)) {
                dataHtml += ' data-' + val[0] + '="' + val[1] + '"';

                // Add extra data attribute
                if (val[0] == 'target') {
                    if (val[1] == '#formModal') {
                        dataHtml += ' data-rel="tooltip" data-placement="top" title="' + _.title.edit + '"';
                    } else if (val[1] == '#removeModal') {
                        dataHtml += ' data-rel="tooltip" data-placement="top" title="' + _.title.delete + '"';
                    }
                }
            } else {
                dataHtml += ' data-' + val + '="' + data[val] + '"';
            }
        });

        if (attrs) {
            $.each(attrs, function(i, val) {
                // console.log(i, val)
                dataHtml += ' ' + val[0] + '="' + val[1] + '"';
            })
        }

        return '<button class="btn ' + classes + '"' +
            dataHtml +
            '>' +
            inner +
            '</button> ';
    }

    _.cleanError = function() {
        $('.help-block').remove();
        $('.has-error').removeClass('has-error');
    }

    _.resetProgressBar = function() {
        _.progressBar
            .addClass('hide')
            .find('.progress-bar')
            .css("width", "0%")
            .text("0%");
    }

    _.onClickAddBtn = function() {
        $('body').on('click', '.btn-add', function(e) {
            var form = $('#form');
            $('#formModal .modal-title').html(_.title.add);
            form.find('input[type=text], input[type=number], input[type=email], input[type=hidden], input[type=password], textarea').not('.js-non-editable').val('');
            form.find('input[type=checkbox], input[type=radio]').prop('checked', false);
            form.find('input[type=file]').val('');
            form.find('select option').prop('selected', false).trigger("change");
            form.find('select').find('option:eq(0)').prop('selected', true);
            $('.js-form-image').remove();
            _.cleanError();
        });
    }

    _.onClickEditBtn = function() {
        var _type, _name, _element, _val;

        $('body').on('click', '.btn-edit', function(e) {
            $('#formModal .modal-title').html(_.title.edit);
            _btn = $(this);
            // Data
            _.editData = _.datatable.row(_btn.closest("tr")).data();

            $('.js-form-image').remove();
            $('input[type=file]').val('');
            // Set Value
            $('#form').find(':input').each(function(i, elem) {

                _element = $(this);
                _type = this.type || this.tagName.toLowerCase();
                _name = _element.attr('name');

                // Skip to next iteration
                if (typeof _name == 'undefined') {
                    return true;
                }

                _val = _.editData[_name.replace(/\[\]/, '')];

                if ((_type == 'checkbox' || _type == 'radio')) {
                    if ($.isArray(_val)) {
                        if ($.inArray(isNaN(_element.val()) ? _element.val() : parseInt(_element.val()),
                                _val) == -1) {
                            _element.prop('checked', false);
                        } else {
                            _element.prop('checked', true);
                        }
                    } else {
                        if (_val == _element.val()) {
                            _element.prop('checked', true);
                        } else {
                            _element.prop('checked', false);
                        }
                    }
                } else if (_type == 'select-multiple') {
                    if (_element.next().is('.select2')) {
                        _element.val(_val).trigger("change");
                    } else {
                        _element.find('option').prop('selected', false);
                        $.each(_val, function(i, el) {
                            _element.find('option[value=' + el.id + ']').prop('selected', true);
                        });
                    }

                } else if (_type == 'file') {

                    if (_val != null && _val != '') {
                        _element.parent().before('<div class="form-group js-form-image"><img src="' + _val + '" alt="" style="width:200px;" class="img-thumbnail" /></div>');
                    }
                } else {
                    _val = $('<textarea />').html(_val).text()
                    _element.val(_val);
                }
            });
            _.cleanError();
        });
    }

    _.onClickFormBtn = function() {
        $('body').on('click', '.ajax-form', function(e) {
            e.preventDefault();
            _btn = $(this);
            _btn.prepend('<i class="fa fa-spinner fa-spin"></i> ');
            _btn.prop('disabled', true);
            _.progressBar.removeClass('hide');

            var form_data = new FormData(document.getElementById('form'));
            $.ajax({
                url: _.options.form.url,
                type: "POST",
                data: form_data,
                contentType: false,
                cache: false,
                processData: false,
                xhr: function() {

                    // Upload Progress
                    var xhr = $.ajaxSettings.xhr();
                    if (xhr.upload) {
                        xhr.upload.addEventListener('progress', function(event) {
                            var percent = 0;
                            var position = event.loaded || event.position;
                            var total = event.total;

                            if (event.lengthComputable) {
                                percent = Math.ceil(position / total * 100);
                            }

                            // Update progressbar
                            _.progressBar.find('.progress-bar').css("width", +percent + "%").text(percent + "%");
                        }, true);
                    }

                    return xhr;
                },
                mimeType: "multipart/form-data"

            }).done(function(response) {
                var res = JSON.parse(response);

                if (res.status == 'error') {
                    // Go to error tab
                    _.goToErrorTab(Object.keys(res.errors)[0])

                    _.cleanError();
                    $.each(res.errors, function(elem, item) {
                        $.each(item, function(i, error) {
                            $('[name=' + elem + ']').after('<span class="help-block">' + error + '</span>').parent().addClass('has-error');
                        });
                    });
                } else {
                    _.datatable.draw();
                    $('#formModal').modal('hide');
                }

                // Reset
                _btn.prop('disabled', false);
                _btn.find('i').remove();
                _.resetProgressBar();

            }).fail(function(response) {
                if (response.status == 422) {
                    var res = JSON.parse(response.responseText);
                    // Go to error tab
                    _.goToErrorTab(Object.keys(res.errors)[0])
                    _.cleanError();
                    $.each(res.errors, function(elem, item) {
                        $.each(item, function(i, error) {
                            $('[name=' + elem + ']').after('<span class="help-block">' + error + '</span>').parent().addClass('has-error');
                        });
                    });
                } else {
                    // Reset
                    $('#formModal').modal('hide');
                    _.cleanError();
                    alert('Ошибка!');
                }
                _btn.prop('disabled', false);
                _btn.find('i').remove();
                _.resetProgressBar();
            });
        });
    }

    _.goToErrorTab = function(field) {
        var _id = $('[name=' + field + ']').closest('.tab-pane').attr('id')
        $('.nav-tabs a[href="#' + _id + '"]').tab('show');
    }

    _.onClickRemoveBtn = function() {
        $('body').on('click', '[data-target="#removeModal"]', function(e) {
            $('#delete_id').val($(this).data('id'));
            $('#delete_form').removeClass('has-error');
            $('#delete_form').find('span.help-block').hide();;
        });
    }

    _.onClickAjaxRemoveBtn = function() {
            $('body').on('click', '.ajax-remove', function(e) {
                e.preventDefault();
                _btn = $(this);
                _btn.prepend('<i class="fa fa-spinner fa-spin"></i> ');
                _btn.prop('disabled', true);
                $.ajax({
                    type: "POST",
                    url: _.options.remove.url,
                    data: $('#delete_form').serialize(),
                    async: true,
                    success: function(response) {
                        if (response.status == 'success') {
                            _.datatable.draw();
                        } else if (response.status == 'error') {
                            alert(response.message);
                        } else {
                            alert('Пожалуйста, обновите страницу');
                        }
                        _btn.prop('disabled', false);
                        _btn.find('i').remove();
                        $('#removeModal').modal('hide');
                    }
                });
            });
        },

        /**
         * Get query string value by name
         * 
         * @param  string name
         * @param  string url
         * @return string
         */
        _.getParameterByName = function(name, url) {
            if (!url) url = window.location.href;
            name = name.replace(/[\[\]]/g, "\\$&");
            var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
                results = regex.exec(url);
            if (!results) return null;
            if (!results[2]) return '';
            return decodeURIComponent(results[2].replace(/\+/g, " "));
        }

    /**
     * Go to current page
     * 
     * @return void
     */
    _.stateLoadParams = function(data) {
            $("#datatable thead input, #datatable thead select").each(function(i, item) {
                $(item).val(data.columns[$(this).parent().index()].search.search);
            });
        },

        /**
         * Initialize bootstap tooltip
         */
        _.tooltip = function() {
            $('[data-rel="tooltip"]').tooltip({
                html: true
            })
        }

    /**
     * Initialize modal title
     */
    _.initTitles = function() {
        var _lang = document.documentElement.lang;
        let _trans = {
            'en': 'Edit',
            'uzl': 'Tahrirlash',
            'uzc': 'Таҳрирлаш',
            'ru': 'Редактировать',
            'kar': 'Таҳрирлаш'
        }

        let _delete = {
            'en': 'Delete',
            'uzl': 'O’chirish',
            'uzc': 'Ўчириш',
            'ru': 'Удалить',
            'kar': 'Ўчириш'
        }

        _.title = {
            add: $('#formModal .modal-title').text(),
            edit: _trans[_lang] || _trans.en,
            delete: _delete[_lang] || _delete.en
        }
    }

    _.drawPage = function() {
        _.datatable.page(_.datatable.page.info().page).draw('page');
    }

    /**
     * Intialize events
     * 
     * @return void
     */
    _.init = function() {
        _.onClickAddBtn();
        _.onClickFormBtn();
        _.onClickRemoveBtn();
        _.onClickAjaxRemoveBtn();
        _.onClickEditBtn();
        _.initTitles();
        _.datatable = $("#datatable").DataTable(_.prepareDatatable());
        $(_.datatable.table().container()).removeClass('form-inline');
        if (_.options.filter) {
            _.initDatableFilter();
        }
        _.tooltip()
    }

    _.init();

    return _;
}